# Building and Publishing TacMap

This guide explains how to build and publish TacMap to PyPI.

## Prerequisites

```bash
pip install build twine
```

## Building the Package

### 1. Clean Previous Builds

```bash
# Remove old build artifacts
rm -rf build/ dist/ *.egg-info
```

### 2. Build Distribution Files

```bash
# Build both wheel and source distribution
python -m build
```

This creates:
- `dist/tacmap-1.0.0-py3-none-any.whl` (wheel)
- `dist/tacmap-1.0.0.tar.gz` (source distribution)

### 3. Check Package

```bash
# Verify the package is properly formatted
twine check dist/*
```

## Testing the Package Locally

### Install from Local Build

```bash
# Install the wheel
pip install dist/tacmap-1.0.0-py3-none-any.whl

# Or install in editable mode for development
pip install -e .
```

### Test the Installation

```bash
# Test the command-line tools
tacmap --help  # Should show help or run the program
tacmap-scanner --help  # Should show scanner

# Test import
python -c "import tacmap; print(tacmap.__version__)"
```

## Publishing to PyPI

### 1. Create PyPI Account

1. Go to https://pypi.org/account/register/
2. Verify your email
3. Set up 2FA (recommended)

### 2. Create API Token

1. Go to https://pypi.org/manage/account/
2. Scroll to "API tokens"
3. Click "Add API token"
4. Name it (e.g., "tacmap-upload")
5. Scope: "Entire account" or specific project
6. Copy the token (starts with `pypi-`)

### 3. Configure Credentials

```bash
# Create or edit ~/.pypirc
cat > ~/.pypirc << EOF
[pypi]
username = __token__
password = pypi-YOUR-TOKEN-HERE
EOF

# Set proper permissions
chmod 600 ~/.pypirc
```

### 4. Upload to Test PyPI (Optional but Recommended)

```bash
# Upload to TestPyPI first
twine upload --repository testpypi dist/*

# Test install from TestPyPI
pip install --index-url https://test.pypi.org/simple/ tacmap
```

### 5. Upload to PyPI

```bash
# Upload to the real PyPI
twine upload dist/*
```

### 6. Verify Upload

```bash
# Check your package on PyPI
open https://pypi.org/project/tacmap/

# Install from PyPI
pip install tacmap
```

## Updating the Package

### 1. Update Version Number

Edit these files:
- `setup.py` - Update `version`
- `pyproject.toml` - Update `version`
- `tacmap/__init__.py` - Update `__version__`
- `CHANGELOG.md` - Add new version entry

### 2. Commit Changes

```bash
git add .
git commit -m "Bump version to X.Y.Z"
git tag vX.Y.Z
git push origin main --tags
```

### 3. Build and Upload

```bash
# Clean old builds
rm -rf build/ dist/ *.egg-info

# Build new version
python -m build

# Check and upload
twine check dist/*
twine upload dist/*
```

## Version Numbering

Follow Semantic Versioning (SemVer):
- **Major** (X.0.0): Breaking changes
- **Minor** (0.X.0): New features, backwards compatible
- **Patch** (0.0.X): Bug fixes, backwards compatible

Examples:
- `1.0.0` - Initial release
- `1.0.1` - Bug fix
- `1.1.0` - New feature
- `2.0.0` - Breaking change

## Troubleshooting

### "Package already exists"
- You uploaded this version already
- Bump the version number and rebuild

### "Invalid credentials"
- Check your API token
- Verify ~/.pypirc configuration
- Token might have expired

### "File name has already been used"
- Clean dist/ folder
- Bump version number
- Rebuild package

### Import errors after install
- Check MANIFEST.in includes all necessary files
- Verify package_data in setup.py
- Ensure __init__.py exists in all modules

## Best Practices

1. **Always test locally first**
2. **Use TestPyPI before real PyPI**
3. **Keep CHANGELOG.md updated**
4. **Tag releases in git**
5. **Test installation in fresh virtualenv**
6. **Include all necessary files in MANIFEST.in**
7. **Write clear commit messages**
8. **Document breaking changes**

## Continuous Integration (Optional)

### GitHub Actions for Auto-Publishing

Create `.github/workflows/publish.yml`:

```yaml
name: Publish to PyPI

on:
  release:
    types: [created]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - uses: actions/setup-python@v4
      with:
        python-version: '3.x'
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install build twine
    - name: Build package
      run: python -m build
    - name: Publish to PyPI
      env:
        TWINE_USERNAME: __token__
        TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
      run: twine upload dist/*
```

Add your PyPI token as a GitHub secret: `PYPI_API_TOKEN`

## Resources

- [Python Packaging Guide](https://packaging.python.org/)
- [PyPI Help](https://pypi.org/help/)
- [Semantic Versioning](https://semver.org/)
- [Twine Documentation](https://twine.readthedocs.io/)

---

Good luck with your release! 🚀
