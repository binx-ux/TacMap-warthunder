# TacMap Quick Reference

## Installation

```bash
pip install tacmap
```

## Basic Commands

```bash
# Run tactical map (demo mode if no config)
tacmap

# Run memory scanner
tacmap-scanner
```

## First Time Setup

1. **Install TacMap**
   ```bash
   pip install tacmap
   ```

2. **Test Demo Mode**
   ```bash
   tacmap
   # Press ESC to exit
   ```

3. **Start War Thunder**
   - Launch War Thunder
   - Enter a match or test drive

4. **Find Memory Addresses**
   ```bash
   tacmap-scanner
   # Run as Administrator
   # Enter PID: 13452 (or whatever it shows)
   # Choose option 1: Scan for float
   # Enter your X coordinate from game
   # Move vehicle
   # Scan again with new coordinate
   # Repeat until <50 addresses
   # Save addresses to file
   ```

5. **Create Config File**
   - Copy `tacmap_config.example.json` to `tacmap_config.json`
   - Edit with found addresses:
   ```json
   {
     "process_name": "aces_BE.exe",
     "addresses": {
       "player": {
         "x_position": "0x12AB34CD",
         "y_position": "0x12AB34D1",
         "z_position": "0x12AB34D5"
       }
     }
   }
   ```

6. **Run with Real Data**
   ```bash
   tacmap
   # Should now show your real position!
   ```

## Controls

| Key | Action |
|-----|--------|
| Arrow Keys | Pan map |
| + / - | Zoom in/out |
| Mouse Wheel | Zoom in/out |
| R | Reset view |
| ESC | Exit |

## Configuration Locations

TacMap looks for config in these locations (in order):
1. `./tacmap_config.json` (current directory)
2. `~/.tacmap/config.json` (home directory)
3. Built-in defaults (demo mode)

## Common Issues

### "War Thunder process not found"
- Make sure War Thunder is running
- Try running scanner as Administrator
- Check if process name is `aces.exe` or `aces_BE.exe`

### "Failed to attach"
- **Run as Administrator**
- Close other memory tools
- Check antivirus isn't blocking

### "No addresses configured"
- Run `tacmap-scanner` first
- Create `tacmap_config.json` with addresses
- Make sure addresses are in hex format: `0x12345678`

### Map shows wrong position
- Addresses changed (game updated)
- Re-run scanner to find new addresses
- Verify you're scanning the correct coordinate

## Memory Address Tips

### Finding X Coordinate
1. Note X position in game (e.g., 1234.5)
2. Scan for `1234.5`
3. Move 500+ meters
4. Scan for new position
5. Repeat 2-3 times

### Y and Z Coordinates
- Usually +4 and +8 bytes from X
- If X is at `0x12345678`:
  - Y likely at `0x1234567C`
  - Z likely at `0x12345680`

### Velocity
- Similar to position (3 floats)
- Changes rapidly when moving
- Usually +12, +16, +20 from position

## Python API

```python
from tacmap import TacticalMap, MemoryReader, Vector3, Entity

# Create map
tac_map = TacticalMap(width=1920, height=1080)

# Create memory reader
mem_reader = MemoryReader("aces_BE.exe")
pid = mem_reader.find_process()
mem_reader.open_process(pid)

# Read position
x = mem_reader.read_float(0x12345678)
y = mem_reader.read_float(0x1234567C)
z = mem_reader.read_float(0x12345680)
pos = Vector3(x, y, z)

# Update map
tac_map.update(pos, [])
tac_map.render()
```

## Safety Reminders

- ⚠️ **READ-ONLY** - Does not modify game
- ⚠️ **Educational Purpose** - Learn about memory reading
- ⚠️ **Use Offline** - Recommended for custom matches only
- ⚠️ **Anti-Cheat Risk** - May be detected by EAC
- ⚠️ **No Warranty** - Use at your own risk

## Support

- Issues: https://github.com/binx-ux/tacmap/issues
- Docs: https://github.com/binx-ux/tacmap#readme

## Version

Check your version:
```bash
python -c "import tacmap; print(tacmap.__version__)"
```

Current version: 1.0.0

---

**Remember**: Use responsibly! This is for educational purposes. Play fair! 🎮
