# TacMap - War Thunder Tactical Map Overlay

A **completely safe**, read-only tactical map overlay for War Thunder that displays game information on a secondary monitor without modifying any game memory.

[![PyPI version](https://badge.fury.io/py/tacmap.svg)](https://badge.fury.io/py/tacmap)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## ⚠️ Important Disclaimers

1. **READ-ONLY**: This tool only READS game memory, it does NOT modify anything
2. **Educational Purpose**: This is for learning about memory reading and game overlays
3. **Use at Own Risk**: While this is read-only, using memory tools with online games may violate ToS
4. **Anti-Cheat**: War Thunder has anti-cheat systems - use this offline or in custom matches only
5. **No Guarantees**: Memory addresses change with each game update

## 📋 Features

- **Real-time tactical map** on secondary monitor
- **Entity tracking** (aircraft, ground vehicles)
- **Position and velocity indicators**
- **Team identification** (friendly/enemy/neutral)
- **Health bars** and distance indicators
- **Zoom and pan controls**
- **Grid overlay** with distance markers
- **Completely non-intrusive** - read-only access

## 📦 Installation

### From PyPI (Recommended)

```bash
pip install tacmap
```

### From Source

```bash
git clone https://github.com/binx-ux/tacmap.git
cd tacmap
pip install -e .
```

### Requirements

```bash
pip install pygame
```

- Python 3.8+
- Windows OS (uses Windows API for memory reading)
- Administrator privileges (required for reading process memory)
- War Thunder (obviously!)

## 🚀 Quick Start

### Step 1: Install TacMap

```bash
pip install tacmap
```

### Step 2: Run Demo Mode

First, test the tactical map interface:

```bash
tacmap
```

This runs in DEMO mode with simulated entities. Test the controls:
- **Arrow Keys**: Pan the map
- **+/-** or **Mouse Wheel**: Zoom in/out
- **R**: Reset view
- **ESC**: Exit

### Step 2: Find Memory Addresses

War Thunder's memory layout changes with each update, so you need to find the addresses first.

1. **Start War Thunder** and enter a match/test drive
2. **Run the memory scanner** (as Administrator):

```bash
tacmap-scanner
```

3. **Note your coordinates** in War Thunder (check the map)
4. **Scan for your X coordinate**:
   - Choose option 1
   - Enter your X coordinate (e.g., 1234.5)
   - Wait for scan to complete

5. **Move your vehicle** to a new position
6. **Scan again** with the new X coordinate
   - Repeat until you have ~10-50 addresses

7. **Monitor for changes**:
   - Choose option 2
   - Move around in War Thunder
   - Addresses that change = position coordinates!

### Step 3: Configure Addresses

Edit `tacmap_config.json` in your current directory with the addresses you found:

```json
{
  "process_name": "aces_BE.exe",
  "addresses": {
    "player": {
      "x_position": "0x12345678",  // Your found address
      "y_position": "0x1234567C",  // Usually +4 bytes
      "z_position": "0x12345680",  // Usually +8 bytes
      ...
    }
  }
}
```

### Step 4: Run Tactical Map

```bash
tacmap
```

The map will now display real game data!

## 🔍 Finding Different Data Types

### Player Position (X, Y, Z)
- These are **3 consecutive floats** (12 bytes total)
- Usually close together in memory
- X, Y, Z are typically +0, +4, +8 bytes apart

### Velocity
- Same format as position
- Changes rapidly when moving
- Often near position data (+12, +16, +20 from position)

### Health
- Single float value (0-100 or similar)
- Decreases when taking damage
- Scan while taking damage to find it

### Team ID
- Usually an integer (1, 2, or similar)
- Doesn't change during match
- 1 = friendly, 2 = enemy (typically)

## 🎮 Controls

| Key | Action |
|-----|--------|
| Arrow Keys | Pan map |
| +/- | Zoom in/out |
| Mouse Wheel | Zoom in/out |
| R | Reset view |
| ESC | Exit |

## 📊 Understanding the Display

### Entity Icons
- **Triangle** = Aircraft
- **Square** = Ground vehicle
- **Circle** = Unknown/other

### Colors
- **Blue** = You (player)
- **Green** = Friendly units
- **Red** = Enemy units
- **Yellow** = Neutral/unknown

### Information
- **Lines** extending from icons = velocity direction
- **Bars below icons** = health (if < 100%)
- **Text** = entity name and distance in meters

## 🛠️ Advanced Usage

### Multi-Entity Tracking

To track multiple entities, you need to find the entity list structure:

1. Find **entity count** address (integer that matches # of entities)
2. Find **entity list base** address
3. Calculate **entity size** (spacing between entities)
4. Map **offsets** for each entity property

This is more complex and may require tools like Cheat Engine for pointer scanning.

### Custom Offsets

Different game modes may use different memory layouts:

- **Air Battles**: Different entity structure
- **Ground Battles**: Vehicle-specific data
- **Naval**: Ship data structures
- **Custom Matches**: May have different layout

You'll need to find addresses for each mode separately.

## 🔧 Troubleshooting

### "Couldn't find War Thunder process"
- Make sure War Thunder is running
- Try different process names in config
- Run scanner as Administrator

### "Failed to attach to process"
- **Run as Administrator** (required for memory reading)
- Close other memory tools (conflicts)
- Check anti-virus isn't blocking

### "No addresses found"
- Value might be out of scan range
- Try wider range in scanner
- Float precision issues (use tolerance)

### "Values are wrong/jumping around"
- Addresses changed (game updated)
- You found unrelated values
- Need to re-scan after game updates

### "Map shows nothing"
- Check config.json addresses are correct
- Verify addresses in memory scanner first
- Make sure process name matches

## 📝 Memory Structure Tips

War Thunder likely uses structures like this:

```cpp
struct Player {
    float x_pos;      // +0x00
    float y_pos;      // +0x04
    float z_pos;      // +0x08
    float x_vel;      // +0x0C
    float y_vel;      // +0x10
    float z_vel;      // +0x14
    int team_id;      // +0x18
    float health;     // +0x1C
    // ... more data
};

struct Entity {
    float x_pos;
    float y_pos;
    float z_pos;
    int type;
    int team;
    // ... more data
};
```

Offsets will vary by version!

## ⚡ Performance Tips

1. **Reduce update rate** in config (map_settings.update_rate_ms)
2. **Limit entity count** (display.max_entities)
3. **Disable features** you don't need (velocity, health bars)
4. **Use lower resolution** if laggy

## 🔐 Safety Notes

- This is **READ-ONLY** - cannot modify game
- May still violate ToS even though read-only
- Recommended for **offline/custom matches only**
- Easy Anti-Cheat may detect memory reading
- Use at your own risk
- Not responsible for bans/issues

## 🔄 Updates

Game updates **will break** memory addresses. After each War Thunder update:

1. Re-run memory scanner
2. Find new addresses
3. Update config.json
4. Test in custom match first

## 📚 Learning Resources

- **Cheat Engine Tutorial**: Basics of memory scanning
- **Game Hacking Forums**: Community knowledge
- **Reverse Engineering Guides**: Understanding game structures
- **Python ctypes Documentation**: Windows API usage

## 🤝 Contributing

Found better ways to locate addresses? Improvements to the tactical map display? Feel free to modify and enhance!

## ⚖️ Legal

This tool is for **educational purposes only**. The author:
- Does NOT encourage violating game ToS
- Is NOT responsible for account bans
- Provides NO warranty or support
- Recommends using offline only

Use responsibly and at your own risk.

## 📧 Notes

- Game memory structures are proprietary to Gaijin Entertainment
- This tool does not contain any game code or assets
- All reverse engineering is for educational purposes
- Respect the game developers and other players

---

**Remember**: The best way to enjoy War Thunder is to play it fairly without external tools. This is purely an educational project for learning about memory reading and game overlays.
