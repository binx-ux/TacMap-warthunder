"""
Entry point for the memory scanner
"""
from .memory_scanner import main

if __name__ == "__main__":
    main()
